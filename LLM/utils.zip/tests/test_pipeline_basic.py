# tests/test_pipeline_basic.py
from pathlib import Path
import shutil
from langgraph.graph import StateGraph, START, END
from graph.training.state import TrainState
from graph.training.nodes.init_context import init_context
from graph.training.nodes.load_dataset import load_dataset

from tests.smoke_test_init_and_dataset import _prepare_raw_dataset  # 재사용

def build_graph():
    g = StateGraph(TrainState)
    g.add_node("init_context", init_context)
    g.add_node("load_dataset", load_dataset)
    g.add_edge(START, "init_context")
    g.add_edge("init_context", "load_dataset")
    g.add_edge("load_dataset", END)
    return g.compile()

def test_pipeline(tmp_path: Path):
    raw_images, raw_labels = _prepare_raw_dataset(tmp_path)
    cfg = tmp_path / "configs" / "training.yaml"
    cfg.parent.mkdir(parents=True, exist_ok=True)
    cfg.write_text("meta:\n  project_name: test\n", encoding="utf-8")

    graph = build_graph()

    out = graph.invoke(TrainState(
        config_path=str(cfg),
        dataset_version="insects@1.0.0",
        raw_images_dir=str(raw_images),
        raw_labels_dir=str(raw_labels),
        names=["ant","bee"]
    ))

    assert out.context and out.context["project_name"] == "test"
    assert out.data and Path(out.data["yaml_path"]).exists()
    assert Path(out.data["train_dir"]).exists()
    assert Path(out.data["val_dir"]).exists()
