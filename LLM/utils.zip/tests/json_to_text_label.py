while(True):
    datas = list(map(float, input().split()))
    # x (0), y (1), width (2), height (3), image_width (4), image_height (5)
    x_c = (datas[0] + datas[2]/2) / datas[4]
    y_c = (datas[1] + datas[3]/2) / datas[5]
    width = datas[2] / datas[4]
    height = datas[3] / datas[5]

    print(f"0 {x_c:.6f} {y_c:.6f} {width:.6f} {height:.6f}")