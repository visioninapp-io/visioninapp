# tests/smoke_test_init_and_dataset.py
from __future__ import annotations
import os
import shutil
from pathlib import Path
from typing import Tuple
from PIL import Image, ImageDraw  # pip install pillow

from langgraph.graph import StateGraph, START, END

# 프로젝트 경로 맞게 수정
from graph.training.state import TrainState
from graph.training.nodes.init_context import init_context
from graph.training.nodes.load_dataset import load_dataset


# --------------------------
# 더미 데이터 생성 헬퍼
# --------------------------
def _make_dummy_yolo_sample(img_path: Path, lbl_path: Path, size: Tuple[int, int]=(320, 240), cls:int=0):
    img_path.parent.mkdir(parents=True, exist_ok=True)
    lbl_path.parent.mkdir(parents=True, exist_ok=True)

    im = Image.new("RGB", size, (220, 220, 220))
    dr = ImageDraw.Draw(im)
    dr.rectangle([40, 40, 160, 160], outline=(0, 0, 0), width=3)
    im.save(img_path)

    label = f"{cls} 0.5 0.5 0.3 0.3\n"  # YOLO 형식 라벨
    lbl_path.write_text(label, encoding="utf-8")


def _prepare_raw_dataset(tmp_root: Path):
    raw_images = tmp_root / "data" / "raw" / "images"
    raw_labels = tmp_root / "data" / "raw" / "labels"

    # 클래스 2개, 이미지 10장 생성
    for i in range(10):
        cls = 0 if i < 5 else 1
        img_path = raw_images / f"img_{i:02d}.jpg"
        lbl_path = raw_labels / f"img_{i:02d}.txt"
        _make_dummy_yolo_sample(img_path, lbl_path, cls=cls)
    return raw_images, raw_labels


# --------------------------
# 메인 테스트 함수
# --------------------------
def main():
    tmp_root = Path("./_tmp_smoke")
    if tmp_root.exists():
        shutil.rmtree(tmp_root)
    tmp_root.mkdir(parents=True, exist_ok=True)

    raw_images_dir, raw_labels_dir = _prepare_raw_dataset(tmp_root)

    # 최소 training.yaml 생성
    cfg_path = tmp_root / "configs" / "training.yaml"
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(
        "meta:\n"
        "  project_name: yolo-training\n"
        f"  log_dir: {str((tmp_root/'runs').as_posix())}\n"
        "data:\n"
        "  split_ratio: [0.8, 0.2]\n",
        encoding="utf-8"
    )

    # 그래프 구성
    g = StateGraph(TrainState)
    g.add_node("init_context", init_context)
    g.add_node("load_dataset", load_dataset)
    g.add_edge(START, "init_context")
    g.add_edge("init_context", "load_dataset")
    g.add_edge("load_dataset", END)
    graph = g.compile()

    # 실행
    state = TrainState(
        config_path=str(cfg_path),
        dataset_version="insects@1.0.0",
        raw_images_dir=str(raw_images_dir),
        raw_labels_dir=str(raw_labels_dir),
        names=["ant", "bee"],
        seed=123,
        run_name="smoke"
    )

    out = graph.invoke(state)

    # 검증 포인트
    assert out.context is not None, "context가 없습니다."
    assert out.data is not None, "data 섹션이 없습니다."
    assert Path(out.data["yaml_path"]).exists(), "data.yaml이 없습니다."
    print("\n✅ SMOKE TEST PASSED")
    print(f"- data.yaml: {out.data['yaml_path']}")
    print(f"- train_dir: {out.data['train_dir']}")
    print(f"- val_dir  : {out.data['val_dir']}")
    print(f"- stats    : {out.dataset_stats}")


if __name__ == "__main__":
    main()
