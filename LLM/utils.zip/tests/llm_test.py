import os, json, traceback
from dotenv import load_dotenv

print("[1] .env 로드")
load_dotenv()
print("OPENAI_API_KEY =", "set" if os.getenv("OPENAI_API_KEY") else "MISSING")

print("[2] 패키지 임포트")
try:
    from langchain_openai import ChatOpenAI
    from langchain_core.prompts import ChatPromptTemplate
    print("langchain_openai / core OK")
except Exception as e:
    print("langchain 임포트 실패:", repr(e))
    raise

print("[3] LLM 호출(샘플)")
try:
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)  # 안전한 모델명
    prompt = ChatPromptTemplate.from_template('{{"echo": "{q}"}}')
    out = (prompt | llm).invoke({"q": "hello"})
    print("LLM raw content:", getattr(out, "content", None))
except Exception as e:
    print("[에러] LLM 호출 실패:", repr(e))
    traceback.print_exc()
